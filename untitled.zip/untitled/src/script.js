//Array (Arreglo) para las imagenes, aquí van a poner las imagenes//
//de cada uno (ES INDIVIDUAL)//

const imagenes = ["https://i.pinimg.com/1200x/74/1b/22/741b227e5165f45986cb2101fbcab685.jpg",
                  
 "https://i.pinimg.com/736x/9b/a7/70/9ba770f8f7023dd008e233cbdd5e90e1.jpg",
     
"https://www.shein.com.mx/ark/default?scene=1&ad_type=DPA&test=5051&goods_id=13039891&pf=PINTEREST&url_from=PINADSDPA&x=https%3A%2F%2Fm.shein.com.mx%2Fark%2Fdefault%3Fscene%3D3%26ad_type%3DDPA%26pf%3Dpinterest%26test%3D5051%26goods_id%3D13039891%26pf%3DPINTEREST%26url_from%3DPINADSDPA&cid=626755916662&setid=2680086673850&link_type=ad_link&pp=0",
                  
"https://i.pinimg.com/736x/a8/00/97/a800970c74da67f7354aa375392af3bd.jpg",
                  
"https://i.pinimg.com/736x/eb/eb/54/ebeb541a223b1c43e4941e46a9f0eb80.jpg",
                 
 ]

//seleccion de elementos//

const boton = document.getElementById("btn-cambiar");

const imagenCard = document.getElementById("card-img");

const textoCard = document.getElementById("card-text");

//contador de las imagenes//

let indice = 0;

// Evento del click //

boton.addEventListener("click", ()=>
{
  //lo siguiente es para que avance la foto //
  indice++;
  
  //el siguiente if es para cuando llegue al final se regreso al inicio//
  
  if(indice >= imagenes.length){
    indice = 0;
    
  }
   // Cambiar imagen y texto//
  imagenCard.src = imagenes[indice];
  textoCard.textContent = 'Mostrando imagen ${indice + 1} de ${imagenes.length}';
});