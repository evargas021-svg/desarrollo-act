//desafio 1 getElementById //
document.getElementById("btn-titulo").addEventListener("click",()=>
                                             {
   const titulo = document.getElementById("titulo");
  titulo.textContent= "Vida antes que muerte. Fuerza antes que debilidad. Viaje antes que destino";
 }                                           );

// Desafío 2 getElementsByClassName
document.getElementById("btn-cajas").addEventListener("click", () => {
  const cajas = document.getElementsByClassName("caja");
  for (let i = 0; i < cajas.length; i++) {
    cajas[i].style.backgroundColor = "#27C2F5";
  }
});

// Desafío 3 querySelector//

document.getElementById("btn-primera").addEventListener("click", () => {
  let primeraCaja = document.querySelector(".caja");
  if (primeraCaja) {
    primeraCaja.style.backgroundColor = "green";
  }
});

 